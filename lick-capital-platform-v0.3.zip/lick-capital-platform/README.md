# LICK CAPITAL — protótipo web v0.3

Protótipo Next.js responsivo com identidade visual preta/dourada, apresentação institucional e oportunidades demonstrativas. Inclui cliente Supabase e schema SQL inicial.

## 1. Configuração local

1. Instale Node.js 20 ou superior.
2. Extraia o ZIP e abra a pasta no terminal.
3. Execute `npm install`.
4. Copie `.env.example` para `.env.local`.
5. Preencha:

```env
NEXT_PUBLIC_SUPABASE_URL=https://SEU_PROJECT_ID.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=SUA_PUBLISHABLE_KEY
```

6. Execute `npm run dev` e abra `http://localhost:3000`.

## 2. Supabase

No painel Supabase, use o SQL Editor e execute `supabase/schema.sql` apenas num projecto de desenvolvimento depois de rever as políticas. A chave publishable pode estar no frontend; nunca coloque `sb_secret_*`, `service_role` ou a password da base de dados em variáveis `NEXT_PUBLIC_*`.

## 3. O que está e não está implementado

- Implementado: página institucional responsiva e cartões de oportunidades fictícias/demonstrativas.
- Preparado: cliente Supabase e estrutura SQL inicial para perfis, oportunidades e manifestações de interesse.
- Ainda não implementado: autenticação, formulários funcionais, painel de utilizador/admin, upload privado de documentos, moderação, notificações, pagamentos ou transacções.
- O selector de moedas e idiomas ainda não faz conversão cambial nem tradução dinâmica.

## 4. Segurança e enquadramento

Este é um MVP de desenvolvimento, não um sistema pronto para produção. Rever e testar RLS, políticas de Storage, validação, auditoria, backups e protecção de dados antes de recolher dados reais. Não usar para receber, guardar ou movimentar dinheiro. Actividades de intermediação, promoção ou oferta de investimentos podem exigir autorização/licenciamento e aconselhamento jurídico em Moçambique.
