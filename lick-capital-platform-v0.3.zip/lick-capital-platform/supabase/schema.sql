-- LICK CAPITAL: schema inicial de protótipo. Rever com especialista antes de produção.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  account_type text not null check (account_type in ('company','investor')),
  organization_name text,
  country text default 'Mozambique',
  preferred_language text default 'pt' check (preferred_language in ('pt','en','fr')),
  created_at timestamptz not null default now()
);

create table if not exists public.opportunities (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  sector text not null,
  summary text not null,
  country text not null default 'Mozambique',
  currency text not null check (currency in ('MZN','USD')),
  target_amount numeric(18,2),
  status text not null default 'draft' check (status in ('draft','submitted','under_review','published','closed')),
  created_at timestamptz not null default now()
);

create table if not exists public.interests (
  id uuid primary key default gen_random_uuid(),
  opportunity_id uuid not null references public.opportunities(id) on delete cascade,
  investor_id uuid not null references auth.users(id) on delete cascade,
  message text,
  status text not null default 'pending' check (status in ('pending','reviewed','withdrawn')),
  created_at timestamptz not null default now(),
  unique(opportunity_id, investor_id)
);

alter table public.profiles enable row level security;
alter table public.opportunities enable row level security;
alter table public.interests enable row level security;

-- Cada utilizador só pode consultar/alterar o próprio perfil.
create policy "profile_select_own" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "profile_insert_own" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "profile_update_own" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- No protótipo, utilizadores autenticados só vêem as próprias oportunidades.
-- A publicação pública exige políticas adicionais revistas antes de produção.
create policy "opportunity_select_owner" on public.opportunities for select to authenticated using (auth.uid() = owner_id);
create policy "opportunity_insert_owner" on public.opportunities for insert to authenticated with check (auth.uid() = owner_id);
create policy "opportunity_update_owner" on public.opportunities for update to authenticated using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

create policy "interest_select_involved" on public.interests for select to authenticated using (auth.uid() = investor_id or exists (select 1 from public.opportunities o where o.id = opportunity_id and o.owner_id = auth.uid()));
create policy "interest_insert_investor" on public.interests for insert to authenticated with check (auth.uid() = investor_id);
