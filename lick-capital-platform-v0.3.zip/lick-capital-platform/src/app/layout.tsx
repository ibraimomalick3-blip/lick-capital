import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'LICK CAPITAL | Connecting Capital', description: 'Connecting Capital. Creating Opportunities.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="pt"><body>{children}</body></html>; }
